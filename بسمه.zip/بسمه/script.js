/* script.js – بسمة المسواك */

// ==============================
// 1. NAVBAR SCROLL EFFECT
// ==============================
const navbar = document.getElementById('navbar');

window.addEventListener('scroll', () => {
  if (window.scrollY > 60) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
  updateActiveNav();
});

// ==============================
// 2. MOBILE NAV TOGGLE
// ==============================
const navToggle = document.getElementById('navToggle');
const navLinks  = document.getElementById('navLinks');

navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
  const spans = navToggle.querySelectorAll('span');
  if (navLinks.classList.contains('open')) {
    spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
    spans[1].style.opacity   = '0';
    spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
  } else {
    spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
  }
});

// Close nav when a link is clicked
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    const spans = navToggle.querySelectorAll('span');
    spans.forEach(s => { s.style.transform = ''; s.style.opacity = ''; });
  });
});

// ==============================
// 3. ACTIVE NAV LINK TRACKING
// ==============================
const sections = document.querySelectorAll('section[id]');
const navItems = document.querySelectorAll('.nav-link');

function updateActiveNav() {
  let current = '';
  sections.forEach(section => {
    const top = section.offsetTop - 120;
    if (window.scrollY >= top) {
      current = section.getAttribute('id');
    }
  });
  navItems.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === '#' + current) {
      link.classList.add('active');
    }
  });
}

// ==============================
// 4. SCROLL REVEAL ANIMATION
// ==============================
const revealTargets = document.querySelectorAll('[data-aos]');

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const delay = entry.target.getAttribute('data-delay') || 0;
      setTimeout(() => {
        entry.target.classList.add('revealed');
      }, parseInt(delay));
      observer.unobserve(entry.target);
    }
  });
}, {
  threshold: 0.12,
  rootMargin: '0px 0px -40px 0px'
});

// Add base animation styles
const style = document.createElement('style');
style.textContent = `
  [data-aos] {
    opacity: 0;
    transform: translateY(30px);
    transition: opacity 0.7s ease, transform 0.7s ease;
  }
  [data-aos="fade-left"] { transform: translateX(40px); }
  [data-aos="fade-right"] { transform: translateX(-40px); }
  [data-aos].revealed {
    opacity: 1;
    transform: none;
  }
`;
document.head.appendChild(style);

revealTargets.forEach(el => observer.observe(el));

// ==============================
// 5. COUNTER ANIMATION (STATS)
// ==============================
function animateCounter(element, target, suffix = '') {
  const duration = 1800;
  const step = 16;
  const steps = duration / step;
  let current = 0;
  const increment = target / steps;

  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      current = target;
      clearInterval(timer);
    }
    element.textContent = (suffix === '+' ? '+' : '') + Math.floor(current).toLocaleString('ar-SA') + (suffix !== '+' ? suffix : '');
  }, step);
}

const statsObserver = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const nums = entry.target.querySelectorAll('.stat-num');
      nums.forEach(num => {
        const text = num.textContent.trim();
        const val = parseInt(text.replace(/[^0-9]/g, ''));
        const suffix = text.includes('+') ? '+' : (text.includes('%') ? '%' : '');
        animateCounter(num, val, suffix);
      });
      statsObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.5 });

const heroStats = document.querySelector('.hero-stats');
if (heroStats) statsObserver.observe(heroStats);

// ==============================
// 6. SMOOTH SCROLLING POLYFILL
// ==============================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ==============================
// 7. FOOTER YEAR
// ==============================
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// ==============================
// 8. SERVICE CARDS STAGGER
// ==============================
const serviceCards = document.querySelectorAll('.service-card');
const serviceObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry, i) => {
    if (entry.isIntersecting) {
      setTimeout(() => {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
      }, i * 100);
      serviceObserver.unobserve(entry.target);
    }
  });
}, { threshold: 0.1 });

serviceCards.forEach(card => {
  card.style.opacity = '0';
  card.style.transform = 'translateY(30px)';
  card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  serviceObserver.observe(card);
});

// ==============================
// 9. GOLD CURSOR TRAIL EFFECT (desktop)
// ==============================
if (window.matchMedia('(hover: hover)').matches) {
  let trail = [];
  const TRAIL_LENGTH = 6;

  for (let i = 0; i < TRAIL_LENGTH; i++) {
    const dot = document.createElement('div');
    dot.style.cssText = `
      position: fixed;
      width: ${6 - i}px;
      height: ${6 - i}px;
      border-radius: 50%;
      background: rgba(200,169,81,${0.5 - i * 0.07});
      pointer-events: none;
      z-index: 9999;
      transition: transform 0.1s ease;
      top: 0; left: 0;
    `;
    document.body.appendChild(dot);
    trail.push({ el: dot, x: 0, y: 0 });
  }

  let mouseX = 0, mouseY = 0;
  window.addEventListener('mousemove', e => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  });

  let prevPositions = Array(TRAIL_LENGTH).fill({ x: 0, y: 0 });

  function animateTrail() {
    prevPositions[0] = { x: mouseX, y: mouseY };
    for (let i = 1; i < TRAIL_LENGTH; i++) {
      prevPositions[i] = {
        x: prevPositions[i].x + (prevPositions[i - 1].x - prevPositions[i].x) * 0.35,
        y: prevPositions[i].y + (prevPositions[i - 1].y - prevPositions[i].y) * 0.35,
      };
    }
    trail.forEach((dot, i) => {
      dot.el.style.left = prevPositions[i].x - (3 - i * 0.5) + 'px';
      dot.el.style.top  = prevPositions[i].y - (3 - i * 0.5) + 'px';
    });
    requestAnimationFrame(animateTrail);
  }

  animateTrail();
}
